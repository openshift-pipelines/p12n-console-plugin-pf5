export const ASTERISK = '*';
